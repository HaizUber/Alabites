<?php include('partials/menugraciouslycons.php'); ?>

<style>
    .main-content {
        padding: 20px;
        background-color: #f7f7f7;
    }

    .main-content h1 {
        font-size: 24px;
        margin-bottom: 20px;
    }

    .message {
        padding: 10px;
        margin-bottom: 20px;
        border-radius: 5px;
        font-weight: bold;
    }

    .message.success {
        background-color: #4caf50;
        color: #fff;
    }

    .message.error {
        background-color: #f44336;
        color: #fff;
    }

    .btn-primary,
    .btn-secondary,
    .btn-danger {
        display: inline-block;
        padding: 10px 20px;
        color: #fff;
        border-radius: 5px;
        text-decoration: none;
        transition: background-color 0.3s ease;
    }

    .btn-primary {
        background-color: #4caf50;
    }

    .btn-primary:hover {
        background-color: #45a049;
    }

    .btn-secondary {
        background-color: #ff9800;
    }

    .btn-secondary:hover {
        background-color: #e68a00;
    }

    .btn-danger {
        background-color: #f44336;
    }

    .btn-danger:hover {
        background-color: #d32f2f;
    }

    .tbl-full {
        width: 100%;
        margin-top: 30px;
    }

    .tbl-full th,
    .tbl-full td {
        padding: 10px;
        text-align: center;
    }

    /* Animation */
    @keyframes fadeIn {
         0% {
            opacity: 0;
        }
        100% {
            opacity: 1;
        }
    }

    .animated-fadeIn {
        animation: fadeIn 0.5s ease;
    }
</style>

<div class="main-content animated-fadeIn">
    <div class="wrapper">
        <h1>Manage Food</h1>

        <a href="<?php echo SITEURL; ?>admin/add-graciouslyfood.php" class="btn-primary">Add Food</a>

        <?php 
        if (isset($_SESSION['add'])) {
            echo "<div class='message success'>" . $_SESSION['add'] . "</div>";
            unset($_SESSION['add']);
        }

        if (isset($_SESSION['delete'])) {
            echo "<div class='message success'>" . $_SESSION['delete'] . "</div>";
            unset($_SESSION['delete']);
        }

        if (isset($_SESSION['upload'])) {
            echo "<div class='message success'>" . $_SESSION['upload'] . "</div>";
            unset($_SESSION['upload']);
        }

        if (isset($_SESSION['unauthorize'])) {
            echo "<div class='message error'>" . $_SESSION['unauthorize'] . "</div>";
            unset($_SESSION['unauthorize']);
        }

        if (isset($_SESSION['update'])) {
            echo "<div class='message success'>" . $_SESSION['update'] . "</div>";
            unset($_SESSION['update']);
        }
        ?>

        <table class="tbl-full">
            <thead>
                <tr>
                    <th>S.N.</th>
                    <th>Title</th>
                    <th>Price</th>
                    <th>Image</th>
                    <th>Featured</th>
                    <th>Active</th>
                    <th>Restaurant ID</th>
                    <th>Actions</th>
                    <th>Stocks</th>
                    <th>Stocks Sold</th>
                </tr>
            </thead>
            <tbody>
			
                <?php
                $sql = "SELECT * FROM tbl_food WHERE category_id = 2";
                $res = mysqli_query($conn, $sql);
                $count = mysqli_num_rows($res);
                $sn = 1;

                if ($count > 0) {
                    while ($row = mysqli_fetch_assoc($res)) {
                        $id = $row['id'];
                        $title = $row['title'];
                        $price = $row['price'];
                        $image_name = $row['image_name'];
                        $featured = $row['featured'];
                        $active = $row['active'];
                        $category_id = $row['category_id'];
                        $Stocks = $row['Stocks'];
                        $qty = $row['qty'];
						$sold=$row['sold'];

                        // Fetch the quantity from the tbl_food table
                        $order_sql = "SELECT qty FROM tbl_food WHERE id = $id";
                        $order_res = mysqli_query($conn, $order_sql);
                        $order_count = mysqli_num_rows($order_res);

                        if ($order_count > 0) {
                            $order_row = mysqli_fetch_assoc($order_res);
                            
                        }

                        $total_stocks = $Stocks - $sold;
                        ?>

                        <tr>
                            <td><?php echo $sn++; ?>. </td>
                            <td><?php echo $title; ?></td>
                            <td>₱<?php echo $price; ?></td>
                            <td>
                                <?php
                                if ($image_name == "") {
                                    echo "<div class='message error'>Image not Added.</div>";
                                } else {
                                    ?>
                                    <img src="<?php echo SITEURL; ?>images/food/<?php echo $image_name; ?>" width="100px">
                                    <?php
                                }
                                ?>
                            </td>
                            <td><?php echo $featured; ?></td>
                            <td><?php echo $active; ?></td>
                            <td><?php echo $category_id; ?></td> <!-- Display the restaurant ID -->
                            <td>
                                <a href="<?php echo SITEURL; ?>admin/update-graciouslyfood.php?id=<?php echo $id; ?>" class="btn-secondary">Update Food</a>
                                <a href="<?php echo SITEURL; ?>admin/delete-graciouslyfood.php?id=<?php echo $id; ?>&image_name=<?php echo $image_name; ?>" class="btn-danger">Delete Food</a>
                            </td>
                            <td><?php echo $total_stocks=$Stocks-$sold; ?></td>
                            <td><?php echo $sold; ?></td>
                        </tr>
                    <?php
                    }
                } else {
                    echo "<tr><td colspan='7' class='message error'>Food not Added Yet.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<?php include('partials/footer.php'); ?>
